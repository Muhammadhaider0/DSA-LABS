# Helper Function #1

def insert(bst, key):
    if bst == {}:
        bst['value']=key
        bst['left']={}
        bst['right']={}
    if key < bst["value"]:
        insert(bst["left"], key)
    elif key > bst['value']:
        insert(bst["right"], key)
    return bst

# Helper Function #2
def exist(bst, key):
    if not bst:
        return False
    elif bst["value"] == key:
        return True
    elif key < bst["value"]:
        return exist(bst["left"], key)
    else:
        return exist(bst["right"], key)


# Helper Function #3
#def minimum(bst, start_node):

# Helper Function #4
def maximum(bst,starting_node):
    def find_starting_node(node, value):
        if not node:
            return None
        if node["value"] == value:
            return node
        elif value < node["value"]:
            return find_starting_node(node["left"], value)
        else:
            return find_starting_node(node["right"], value)

    starting_node = find_starting_node(bst, starting_node)
    #print(starting_node)
    if not starting_node:
        return None
    
    current_node = starting_node
    while current_node["right"]:
        current_node = current_node["right"]
    
    return current_node

# Helper Function #5
def inorder_traversal(bst, res):
    if bst == {}:
        return
    
    inorder_traversal(bst['left'], res)
    
    res.append(bst['value'])
    
    inorder_traversal(bst['right'], res)

# Helper Function #6
def preorder_traversal(bst, res):
    if bst == {}:
        return
    
    res.append(bst['value'])
    
    preorder_traversal(bst['left'], res)
    
    preorder_traversal(bst['right'], res)

# Helper Function #7
def postorder_traversal(bst, res):
    if bst == {}:
        return
    
    postorder_traversal(bst["left"], res)
    
    postorder_traversal(bst["right"], res)
    
    res.append(bst["value"])    

# Helper Function #8
def successor(bst, key, successor_node=None):
    def find_minimum_node(node):
    # """Find the node with the minimum value in the BST."""
        while node['left']:
            node = node['left']
        return node
    def successor_bst(bst, key, successor_node=None):
        """Find the in-order successor of a given key in the BST."""
        if not bst:
            return successor_node
        
        if key < bst['value']:

            return successor_bst(bst['left'], key, bst)
        elif key > bst['value']:

            return successor_bst(bst['right'], key, successor_node)
        else:

            if bst['right']:
                return find_minimum_node(bst['right'])
            else:
                return successor_node
    new_bst = successor_bst(bst, key, successor_node)
    if new_bst==None:
        return(None)
    return new_bst['value']




def minimum(bst, start_node):
    def find_starting_node(node, value):
        if not node:
            return None
        if node["value"] == value:
            return node
        elif value < node["value"]:
            return find_starting_node(node["left"], value)
        else:
            return find_starting_node(node["right"], value)

    starting_node = find_starting_node(bst, start_node)
    #print(starting_node)
    if not starting_node:
        return None
    
    current_node = starting_node
    while current_node["left"]:
        current_node = current_node["left"]
    
    return current_node

# Example usage:
'''bst = {'value': 68, 'left': {'value': 61, 'left': {'value': 50, 'left': {'value': 4, 'left': {}, 'right': {}}, 'right': {}}, 'right': {'value': 66, 'left': {}, 'right': {}}}, 'right': {'value': 88, 'left': {'value': 76, 'left': {}, 'right': {'value': 82, 'left': {}, 'right': {}}}, 'right': {'value': 89, 'left': {}, 'right': {'value': 94, 'left': {}, 'right': {}}}}}

starting_node = 89
minimum_node = minimum(bst, starting_node)
print(minimum_node)  
'''

