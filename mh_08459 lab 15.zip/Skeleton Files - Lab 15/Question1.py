from HelperFunctions import *

def Question1():
  keys = [68, 88, 61, 89, 94, 50, 4, 76, 66, 82]

  
  bst = {}


  for key in keys:
      

      bst = insert(bst, key)


  print(bst)

  exists_50 = exist(bst, 50)
  print(exists_50)
  exists_49 = exist(bst, 49)
  print(exists_49)
  min_from_68 = minimum(bst, 68)
  print(min_from_68)
  min_from_88 = minimum(bst, 88)
  print(min_from_88)
  max_from_68 = maximum(bst, 68)
  print(max_from_68)
  max_from_61 = maximum(bst, 61)
  print(max_from_61)

  result_inorder = []
  inorder_traversal(bst, result_inorder)


  print(result_inorder)

  result_preorder = []


  preorder_traversal(bst, result_preorder)


  print(result_preorder)

  result_postorder = []
  postorder_traversal(bst, result_postorder)

  print(result_postorder)

  successor_76 = successor(bst, 76)
  print(successor_76)