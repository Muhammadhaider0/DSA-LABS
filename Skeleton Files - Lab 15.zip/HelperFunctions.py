# Helper Function #1
def insert(bst, key):
    pass

# Helper Function #2
def exist(bst, key):
    pass

# Helper Function #3
def minimum(bst, starting_node):
    pass

# Helper Function #4
def maximum(bst,starting_node):
    pass

# Helper Function #5
def inorder_traversal(bst, res):
    pass

# Helper Function #6
def preorder_traversal(bst, res):
    pass

# Helper Function #7
def postorder_traversal(bst, res):
    pass
    
# Helper Function #8
def successor(BST, key, successor_node=None):
    pass