from HelperFunctions import *

def Question1():
  pass
  # Question 1a

  # Question 1b

  # Question 1c
  
  # Question 1d

  # Question 1e

  # Question 1f

  # Question 1g

  # Question 1h

  # Question 1i

  # Question 1j

  # Question 1k
  

## Testing
# Question1()

## Expected Outputs
## 1a
# {'value': 68, 'left': {'value': 61, 'left': {'value': 50, 'left': {'value': 4, 'left': {}, 'right': {}}, 'right': {}}, 'right': {'value': 66, 'left': {}, 'right': {}}}, 'right': {'value': 88, 'left': {'value': 76, 'left': {}, 'right': {'value': 82, 'left': {}, 'right': {}}}, 'right': {'value': 89, 'left': {}, 'right': {'value': 94, 'left': {}, 'right': {}}}}}

## 1b
# True 

## 1c
# False 

## 1d
# 4

## 1e
# 76

## 1f
# 94

## 1g
# 66

## 1h
# [4, 50, 61, 66, 68, 76, 82, 88, 89, 94]

## 1i
# [68, 61, 50, 4, 66, 88, 76, 82, 89, 94]

## 1j
# [4, 50, 66, 61, 82, 76, 94, 89, 88, 68]

## 1k
# 82