def quick_sort_by_column_number(array, low, high, column):
    pass

# Testing
matrix = [['square', 'rectangle', 'triangle'],['chair', 'table', 'house'],['motor cycle', 'car', 'truck']]
quick_sort_by_column_number(matrix, 0, 2, 1)

# Should print:
# [['motor cycle', 'car', 'truck'], ['chair', 'table', 'house'], ['square', 'rectangle', 'triangle']]
# [['motor cycle', 'car', 'truck'], ['square', 'rectangle', 'triangle'], ['chair', 'table', 'house']]

matrix = [[75, 28, 12], [63, 37, 23], [84, 15, 49]]
quick_sort_by_column_number(matrix,0, 2, 1)

# Should print:
# [[84, 15, 49], [63, 37, 23], [75, 28, 12]]
# [[84, 15, 49], [75, 28, 12], [63, 37, 23]]