# Function to perform quicksort
def quick_sort_rectangles(array, low, high, column):
    pass

# Testing
rectangle_records  = [{"ID":"Rect1","Length": 40 ,"Breadth": 25 ,"Color":"red"} , {"ID":"Rect2","Length":30 ,"Breadth": 20 ,"Color":"blue"} , {"ID":"Rect3","Length": 70 ,"Breadth": 45 ,"Color":"green"} , {"ID":"Rect4","Length": 20 ,"Breadth": 10 ,"Color":"purple"}]
quick_sort_rectangles(rectangle_records, 0, len(rectangle_records)-1, "Length")

# Should print:
# [{'ID': 'Rect4', 'Length': 20, 'Breadth': 10, 'Color': 'purple'}, {'ID': 'Rect2', 'Length': 30, 'Breadth': 20, 'Color': 'blue'}, {'ID': 'Rect1', 'Length': 40, 'Breadth': 25, 'Color': 'red'}, {'ID': 'Rect3', 'Length': 70, 'Breadth': 45, 'Color': 'green'}]
# [{'ID': 'Rect4', 'Length': 20, 'Breadth': 10, 'Color': 'purple'}, {'ID': 'Rect2', 'Length': 30, 'Breadth': 20, 'Color': 'blue'}, {'ID': 'Rect1', 'Length': 40, 'Breadth': 25, 'Color': 'red'}, {'ID': 'Rect3', 'Length': 70, 'Breadth': 45, 'Color': 'green'}]