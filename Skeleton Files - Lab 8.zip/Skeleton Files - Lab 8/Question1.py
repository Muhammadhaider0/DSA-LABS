def quick_sort(array, low, high):
    pass

# Testing
arr = [10, 7, 8, 9, 1, 5]
quick_sort(arr, 0, len(arr) - 1)

# Should print:
# [5, 7, 1, 8, 10, 9]
# [1, 5, 7, 8, 10, 9]
# [1, 5, 7, 8, 10, 9]
# [1, 5, 7, 8, 9, 10]