def addNodes(G, nodes):
    pass

def addEdges(G, edges, directed=False):
    pass

def displayGraph(G):
    pass

def listOfNodes(G):
    pass

def listOfEdges(G, directed=False):
    pass

def getNeighbors(G, nodes):
    pass

def removeNode(G, node):
    pass

def removeNodes(G, nodes):
    pass

def getNearestNeighbor(G, node):
    pass