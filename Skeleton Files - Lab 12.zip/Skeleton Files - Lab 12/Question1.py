from Helper_Functions import *

def dfs(G,s):
    pass

# # Testing 
# G = {0: [(1, 1), (2, 1)], 1: [(2, 1), (3, 1)], 2: [(4, 1)], 3: [(4, 1), (5, 1)], 4: [(5, 1)], 5: []}
# print(dfs(G, 0))
# # Should print [0, 2, 4, 5, 1, 3]