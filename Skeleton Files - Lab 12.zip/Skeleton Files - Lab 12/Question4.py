from Helper_Functions import *

def nodes_of_level(G,level):
    pass

# # Testing
# G = {'s': [(1, 1), (2, 1)], 1: [(3, 1), (4, 1), (5, 1)], 2: [(6, 1)], 3: [], 4: [], 5: [], 6: [(7, 1)], 7: []}

# print(nodes_of_level(G, 3))
# # Should print [7]

# print(nodes_of_level(G, 1))
# # Should print [1, 2]