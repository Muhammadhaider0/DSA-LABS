from Helper_Functions import *

def bfs(G,root):
    pass

# # Testing
# G = {'s': [(1, 1), (2, 1)], 1: [(3, 1), (4, 1), (5, 1)], 2: [(6, 1)], 3: [], 4: [], 5: [], 6: [(7, 1)], 7: []}
# print(bfs(G,'s'))
# # Should print ['s', 1, 2, 3, 4, 5, 6, 7]