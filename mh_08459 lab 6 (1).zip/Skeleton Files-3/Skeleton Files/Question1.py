def binary_search_iterative(lst,item):
    low=0
    high=len(lst)-1
    mid=len(lst)//2
    
    while low <= high:
        if lst[mid]==item:
            return(mid)
        else:
            if lst[mid]>item:
                high=mid-1
                mid=(low+high)//2

            else:
                low=mid+1
                mid=(low+high)//2
    return -1
#print(9//2)        
if __name__ == "__main__":
    print(binary_search_iterative([0, 1, 2, 8, 13, 17, 19, 32, 42],3)) #Output should be -1
    print(binary_search_iterative([0, 1, 2, 8, 13, 17, 19, 32, 42],17)) #Output should be 5
