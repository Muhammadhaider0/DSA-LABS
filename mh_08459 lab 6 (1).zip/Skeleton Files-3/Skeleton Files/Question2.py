def binary_search_iterative_modified(lst,item):
    low=0
    high=len(lst)-1
    mid=len(lst)//2
    
    while low <= high:
        if lst[mid]==item:
            return(mid)
        else:
            if lst[mid]>item:
                high=mid-1
                if high<low:
                    break
                mid=(low+high)//2

            else:
                low=mid+1
                mid=(low+high)//2

    lst.insert(mid,item)
    return mid

if __name__ == "__main__":
    print(binary_search_iterative_modified([0, 1, 2, 8, 13, 17, 19, 32, 42], 8)) # Output should be 3
    print(binary_search_iterative_modified([0, 1, 2, 3, 8, 13, 17, 19, 32, 42], -1)) # Output should be 0
    