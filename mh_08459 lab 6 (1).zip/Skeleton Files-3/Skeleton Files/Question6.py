def update_record(students_records, ID, record_title, data):
    left, right = 0, len(students_records) - 1
    found_index = -1

    while left <= right:
        mid = (left + right) // 2
        current_id = students_records[mid][0]

        if current_id == ID:
            found_index = mid
            break
        elif current_id < ID:
            left = mid + 1
        else:
            right = mid - 1

    if found_index == -1:
        return "Record not found"

    if record_title == "ID":
        return "ID cannot be updated"

    if record_title == "Email":
        students_records[found_index] = (ID, data, *students_records[found_index][2:])
    elif record_title == "Mid1":
        students_records[found_index] = (ID, students_records[found_index][1], data, students_records[found_index][3])
    elif record_title == "Mid2":
        students_records[found_index] = (ID, students_records[found_index][1], students_records[found_index][2], data)

    return "Record updated"

if __name__ == "__main__":
    # Output should be [('aa02822', 'ea02822', 80, 65), ('ea02822', 'updated@gmail.com', 80, 65), ('fa08877', 'fa08877@st.habib.edu.pk', 66, 67), ('gh04588', 'gh04588@st.habib.edu.pk', 33, 50)]
    print(update_record([('aa02822', 'ea02822', 80, 65), ('ea02822', 'ea02822@st.habib.edu.pk', 80, 65), ('fa08877', 'fa08877@st.habib.edu.pk', 66, 67), ('gh04588', 'gh04588@st.habib.edu.pk', 33, 50)],'ea02822','Email','updated@gmail.com'))