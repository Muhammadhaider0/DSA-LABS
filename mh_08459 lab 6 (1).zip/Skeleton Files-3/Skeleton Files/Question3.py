def binary_search_recursive(lst, item, low, high):
    mid=(low+high)//2
    if high<low:
        return (-1)
    else:
        if lst[mid]==item:
            return(mid)

        elif lst[mid]>item:
            high=mid-1
            #mid=(low+high)//2
            #print(low,high)
            return(binary_search_recursive(lst,item,low,high))

        elif lst[mid]<item:            
            low=mid + 1
            #mid=(low+high)//2
            #print(low,high)
            return(binary_search_recursive(lst,item,low,high))

if __name__ == "__main__":
    print(binary_search_recursive([0, 1, 2, 8, 13, 17, 19, 32, 42], 3, 0, 8)) # Output should be -1
    print(binary_search_recursive([0, 1, 2, 8, 13, 17, 19, 32, 42], 19, 0, 8)) # Output should be 6