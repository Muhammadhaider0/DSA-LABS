
def finding_multiple(lst, item):
    final=[]
    low=0
    high=len(lst)
    while high-low>=1:
        if lst[low]==item:
            final.append(low)
            low+=1
        else:
            low+=1
    return final
'''
    linear_result = linear_search(lst, item)
    binary_result = binary_search(lst, item)
    
    return list(set(linear_result + binary_result)) 
def linear_search(lst, item):
    indexes = []
    for i in range(len(lst)):
        if lst[i] == item:
            indexes.append(i)
    return indexes

def binary_search(lst, item):
    indexes = []
    left, right = 0, len(lst) - 1

    while left <= right:
        mid = (left + right) // 2
        if lst[mid] == item:
            indexes.append(mid)

            # Check for additional occurrences on the left side
            left_ptr = mid - 1
            while left_ptr >= 0 and lst[left_ptr] == item:
                indexes.append(left_ptr)
                left_ptr -= 1

            # Check for additional occurrences on the right side
            right_ptr = mid + 1
            while right_ptr < len(lst) and lst[right_ptr] == item:
                indexes.append(right_ptr)
                right_ptr += 1

            return indexes

        elif lst[mid] < item:
            left = mid + 1
        else:
            right = mid - 1

    return indexes

'''
if __name__ == "__main__":
    print(finding_multiple([0, 1, 2, 8, 13, 17 ,17 , 17 ,17, 19, 32, 42], 17)) # Output should be [5, 6, 7, 8]
    print(finding_multiple([0, 1, 2, 8, 13, 17 ,17 , 17 ,17, 19, 32, 42], 34)) # Output should be []