def binary_search_recursive_modified(lst, item, low, high):
    mid=(low+high)//2
    if high<low:
        lst.insert(mid+1,item)
        return (mid+1)
    else:
        if lst[mid]==item:
            return(mid)

        elif lst[mid]>item:
            high=mid-1
            if high<low:
                return mid
            return(binary_search_recursive_modified(lst,item,low,high))

        elif lst[mid]<item:            
            low=mid + 1
            return(binary_search_recursive_modified(lst,item,low,high))
    

if __name__ == "__main__":
    print(binary_search_recursive_modified([0, 1, 2, 8, 13, 17, 19, 32, 42], 3, 0, 8)) # Output should be 3
    print(binary_search_recursive_modified([0, 1, 2, 8, 13, 17, 19, 32, 42], 17, 0, 8)) # Output should be 5